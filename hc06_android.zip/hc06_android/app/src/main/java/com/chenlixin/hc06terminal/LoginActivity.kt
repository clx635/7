package com.chenlixin.hc06terminal

import android.content.Intent
import android.os.Bundle
import android.text.method.PasswordTransformationMethod
import androidx.appcompat.app.AppCompatActivity
import com.chenlixin.hc06terminal.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isLoggedIn()) {
            startMain()
            return
        }
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.showPasswordCheck.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                binding.passwordInput.transformationMethod = null
            } else {
                binding.passwordInput.transformationMethod = PasswordTransformationMethod.getInstance()
            }
            binding.passwordInput.setSelection(binding.passwordInput.text?.length ?: 0)
        }

        binding.loginButton.setOnClickListener { attemptLogin() }
    }

    private fun attemptLogin() {
        val username = binding.usernameInput.text?.toString().orEmpty().trim()
        val password = binding.passwordInput.text?.toString().orEmpty().trim()
        val defaultMatched = username == "周鸿宇" && password == "202240680313"
        val storedMatched = AccountStorage.load(this).any {
            it.username == username && it.password == password
        }
        if (defaultMatched || storedMatched) {
            setLoggedIn(true)
            binding.loginStatus.text = "登录成功"
            startMain()
        } else {
            setLoggedIn(false)
            binding.loginStatus.text = "账号或密码错误"
        }
    }

    private fun startMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    private fun isLoggedIn(): Boolean {
        val prefs = getSharedPreferences("auth_prefs", MODE_PRIVATE)
        return prefs.getBoolean("logged_in", false)
    }

    private fun setLoggedIn(value: Boolean) {
        val prefs = getSharedPreferences("auth_prefs", MODE_PRIVATE)
        prefs.edit().putBoolean("logged_in", value).apply()
    }
}
