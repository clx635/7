package com.chenlixin.hc06terminal

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.method.ScrollingMovementMethod
import android.widget.ArrayAdapter
import android.widget.AdapterView
import androidx.activity.result.contract.ActivityResultContracts.CreateDocument
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.chenlixin.hc06terminal.databinding.ActivityMainBinding
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var selectedDevice: BluetoothDevice? = null
    private var socket: BluetoothSocket? = null
    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null
    private val executor = Executors.newSingleThreadExecutor()
    private var deviceNames: List<String> = emptyList()
    private var deviceList: List<BluetoothDevice> = emptyList()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastDevice: BluetoothDevice? = null
    private var reconnectAttempts = 0
    private var reconnecting = false
    private var manualDisconnect = false
    private val maxReconnectAttempts = 5
    private val rxBuffer = StringBuilder()
    private var loggedIn = false
    private var autoSaveEnabled = false
    private var autoSaveMinutes = 0
    private val autoSaveRunnable = Runnable {
        if (autoSaveEnabled && loggedIn) {
            saveLogToFile(true)
            scheduleAutoSave()
        }
    }

    private val enableBluetoothLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            refreshPairedDevices()
        }

    private val exportLogLauncher =
        registerForActivityResult(CreateDocument("text/plain")) { uri ->
            if (uri == null) {
                appendLog("日志导出已取消")
                return@registerForActivityResult
            }
            val text = binding.logText.text?.toString().orEmpty()
            try {
                contentResolver.openOutputStream(uri)?.use { stream ->
                    stream.write(text.toByteArray(Charsets.UTF_8))
                }
                appendLog("日志导出成功")
            } catch (e: Exception) {
                appendLog("日志导出失败: ${e.message}")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!isLoggedIn()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.logText.movementMethod = ScrollingMovementMethod()

        binding.refreshButton.setOnClickListener { refreshPairedDevices() }
        binding.connectButton.setOnClickListener { connectSelected() }
        binding.disconnectButton.setOnClickListener { disconnect(true) }
        binding.sendButton.setOnClickListener { sendText(binding.sendInput.text?.toString().orEmpty()) }
        binding.exportButton.setOnClickListener { exportLog() }
        binding.manageAccountsButton.setOnClickListener {
            startActivity(Intent(this, AccountManageActivity::class.java))
        }
        binding.autoSaveButton.setOnClickListener { toggleAutoSave() }
        binding.cmdSend1.setOnClickListener { sendText(binding.cmdInput1.text?.toString().orEmpty()) }
        binding.cmdSend2.setOnClickListener { sendText(binding.cmdInput2.text?.toString().orEmpty()) }
        binding.cmdSend3.setOnClickListener { sendText(binding.cmdInput3.text?.toString().orEmpty()) }
        binding.cmdSend4.setOnClickListener { sendText(binding.cmdInput4.text?.toString().orEmpty()) }

        binding.deviceSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: android.view.View?,
                position: Int,
                id: Long
            ) {
                selectedDevice = deviceList.getOrNull(position)
                val name = deviceNames.getOrNull(position) ?: ""
                appendLog("已选择设备: $name")
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                selectedDevice = null
            }
        }

        ensureBluetoothEnabled()
        refreshPairedDevices()
        loggedIn = true
        updateUiByLogin(true)
    }

    private fun ensureBluetoothEnabled() {
        if (bluetoothAdapter == null) {
            appendLog("设备不支持蓝牙")
            return
        }
        if (!bluetoothAdapter.isEnabled) {
            val intent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            enableBluetoothLauncher.launch(intent)
        }
    }

    private fun refreshPairedDevices() {
        if (bluetoothAdapter == null) {
            appendLog("设备不支持蓝牙")
            return
        }
        if (!hasBluetoothConnectPermission()) {
            requestBluetoothPermissions()
            return
        }
        val bonded = bluetoothAdapter.bondedDevices?.toList().orEmpty()
        deviceList = bonded
        deviceNames = bonded.map { device ->
            val name = device.name ?: "Unknown"
            "$name (${device.address})"
        }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, deviceNames)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.deviceSpinner.adapter = adapter
        appendLog("已配对设备数量: ${deviceNames.size}")
    }

    private fun connectSelected() {
        if (!loggedIn) {
            appendLog("请先登录")
            return
        }
        val device = selectedDevice
        if (device == null) {
            appendLog("请先选择HC-06设备")
            return
        }
        if (!hasBluetoothConnectPermission()) {
            requestBluetoothPermissions()
            return
        }
        executor.execute {
            try {
                bluetoothAdapter?.cancelDiscovery()
                val s = device.createRfcommSocketToServiceRecord(sppUuid)
                s.connect()
                socket = s
                inputStream = s.inputStream
                outputStream = s.outputStream
                lastDevice = device
                reconnectAttempts = 0
                reconnecting = false
                manualDisconnect = false
                runOnUiThread { appendLog("连接成功: ${device.name}") }
                startReadLoop()
            } catch (e: Exception) {
                runOnUiThread { appendLog("连接失败: ${e.message}") }
                disconnect(false)
            }
        }
    }

    private fun startReadLoop() {
        executor.execute {
            val buffer = ByteArray(1024)
            while (socket?.isConnected == true) {
                try {
                    val count = inputStream?.read(buffer) ?: -1
                    if (count > 0) {
                        val bytes = buffer.copyOfRange(0, count)
                        handleReceived(bytes)
                    }
                } catch (e: Exception) {
                    runOnUiThread { appendLog("接收异常: ${e.message}") }
                    disconnect(false)
                    break
                }
            }
        }
    }

    private fun sendText(text: String) {
        if (!loggedIn) {
            appendLog("请先登录")
            return
        }
        if (text.isBlank()) {
            appendLog("发送内容为空")
            return
        }
        executor.execute {
            try {
                val bytes = if (binding.hexSendCheck.isChecked) {
                    parseHex(text)
                } else {
                    (text + "\n").toByteArray(Charsets.UTF_8)
                }
                outputStream?.write(bytes)
                runOnUiThread {
                    if (binding.hexSendCheck.isChecked) {
                        appendLog("TX HEX: ${bytesToHex(bytes)}")
                    } else {
                        appendLog("TX: $text")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { appendLog("发送失败: ${e.message}") }
            }
        }
    }

    private fun disconnect(manual: Boolean) {
        manualDisconnect = manual
        try {
            inputStream?.close()
        } catch (_: Exception) {
        }
        try {
            outputStream?.close()
        } catch (_: Exception) {
        }
        try {
            socket?.close()
        } catch (_: Exception) {
        }
        socket = null
        inputStream = null
        outputStream = null
        runOnUiThread { appendLog("已断开连接") }
        if (!manualDisconnect) {
            scheduleReconnect()
        }
    }

    private fun appendLog(message: String) {
        val current = binding.logText.text?.toString().orEmpty()
        val updated = if (current.isBlank()) message else current + "\n" + message
        binding.logText.text = updated
        binding.logScroll.post {
            binding.logScroll.fullScroll(android.view.View.FOCUS_DOWN)
        }
    }

    private fun handleReceived(bytes: ByteArray) {
        runOnUiThread {
            if (binding.hexDisplayCheck.isChecked) {
                appendLog("RX HEX [${beijingTime()}]: ${bytesToHex(bytes)}")
            }
        }
        val textChunk = try {
            String(bytes, Charsets.UTF_8)
        } catch (_: Exception) {
            ""
        }
        if (textChunk.isNotEmpty()) {
            rxBuffer.append(textChunk)
            var index = rxBuffer.indexOf("\n")
            while (index >= 0) {
                val line = rxBuffer.substring(0, index).trimEnd('\r')
                rxBuffer.delete(0, index + 1)
                if (line.isNotBlank()) {
                    runOnUiThread { appendLog("RX [${beijingTime()}]: $line") }
                    if (binding.parseCheck.isChecked) {
                        runOnUiThread { appendLog(parseLine(line)) }
                    }
                }
                index = rxBuffer.indexOf("\n")
            }
        }
    }

    private fun parseLine(line: String): String {
        return when {
            line.contains("=") -> {
                val parts = line.split("=", limit = 2)
                val key = parts.getOrNull(0)?.trim().orEmpty()
                val value = parts.getOrNull(1)?.trim().orEmpty()
                "解析: $key = $value"
            }
            line.contains(":") -> {
                val parts = line.split(":", limit = 2)
                val key = parts.getOrNull(0)?.trim().orEmpty()
                val value = parts.getOrNull(1)?.trim().orEmpty()
                "解析: $key : $value"
            }
            line.contains(",") -> {
                val parts = line.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                if (parts.isEmpty()) {
                    "解析: 空数据"
                } else {
                    "解析: 列表(${parts.size}) ${parts.joinToString(" | ")}"
                }
            }
            else -> "解析: $line"
        }
    }

    private fun parseHex(text: String): ByteArray {
        val cleaned = text.replace("0x", "", ignoreCase = true).replace("\\s".toRegex(), "")
        if (cleaned.isEmpty() || cleaned.length % 2 != 0) {
            throw IllegalArgumentException("十六进制格式错误")
        }
        val bytes = ByteArray(cleaned.length / 2)
        var i = 0
        while (i < cleaned.length) {
            val byteStr = cleaned.substring(i, i + 2)
            bytes[i / 2] = byteStr.toInt(16).toByte()
            i += 2
        }
        return bytes
    }

    private fun bytesToHex(bytes: ByteArray): String {
        return bytes.joinToString(" ") { "%02X".format(it) }
    }

    private fun scheduleReconnect() {
        if (reconnecting || lastDevice == null || !loggedIn) {
            return
        }
        if (reconnectAttempts >= maxReconnectAttempts) {
            appendLog("自动重连已停止")
            reconnecting = false
            return
        }
        reconnecting = true
        reconnectAttempts += 1
        val delayMs = 1000L * (1 shl (reconnectAttempts - 1)).coerceAtMost(16)
        appendLog("将在${delayMs / 1000}秒后自动重连")
        mainHandler.postDelayed({
            reconnecting = false
            if (socket?.isConnected == true) {
                return@postDelayed
            }
            connectLastDevice()
        }, delayMs)
    }

    private fun connectLastDevice() {
        val device = lastDevice ?: return
        selectedDevice = device
        connectSelected()
    }

    private fun exportLog() {
        if (!loggedIn) {
            appendLog("请先登录")
            return
        }
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(System.currentTimeMillis())
        val fileName = "hc06_log_$timestamp.txt"
        exportLogLauncher.launch(fileName)
    }

    private fun toggleAutoSave() {
        if (autoSaveEnabled) {
            stopAutoSave()
            return
        }
        val minutes = binding.autoSaveMinutesInput.text?.toString().orEmpty().trim().toIntOrNull()
        if (minutes == null || minutes <= 0) {
            appendLog("请输入有效的保存间隔(分钟)")
            return
        }
        autoSaveMinutes = minutes
        autoSaveEnabled = true
        binding.autoSaveButton.text = "关闭"
        binding.autoSaveStatus.text = "自动保存已开启: ${autoSaveMinutes}分钟"
        scheduleAutoSave()
        appendLog("自动保存已开启: ${autoSaveMinutes}分钟")
    }

    private fun scheduleAutoSave() {
        mainHandler.removeCallbacks(autoSaveRunnable)
        if (!autoSaveEnabled || autoSaveMinutes <= 0) {
            return
        }
        val delay = autoSaveMinutes * 60_000L
        mainHandler.postDelayed(autoSaveRunnable, delay)
    }

    private fun stopAutoSave() {
        autoSaveEnabled = false
        autoSaveMinutes = 0
        mainHandler.removeCallbacks(autoSaveRunnable)
        binding.autoSaveButton.text = "开启"
        binding.autoSaveStatus.text = "自动保存未开启"
        appendLog("自动保存已关闭")
    }

    private fun saveLogToFile(auto: Boolean) {
        val text = binding.logText.text?.toString().orEmpty()
        if (text.isBlank()) {
            if (!auto) {
                appendLog("日志为空")
            }
            return
        }
        val dir = getExternalFilesDir(null) ?: filesDir
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).apply {
            timeZone = TimeZone.getTimeZone("Asia/Shanghai")
        }.format(System.currentTimeMillis())
        val fileName = "hc06_log_${if (auto) "auto_" else ""}$timestamp.txt"
        val file = File(dir, fileName)
        try {
            file.writeText(text, Charsets.UTF_8)
            if (auto) {
                appendLog("自动保存日志: ${file.name}")
            } else {
                appendLog("已保存日志: ${file.name}")
            }
        } catch (e: Exception) {
            appendLog("保存日志失败: ${e.message}")
        }
    }

    private fun beijingTime(): String {
        val format = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        format.timeZone = TimeZone.getTimeZone("Asia/Shanghai")
        return format.format(System.currentTimeMillis())
    }

    private fun updateUiByLogin(enabled: Boolean) {
        binding.refreshButton.isEnabled = enabled
        binding.connectButton.isEnabled = enabled
        binding.disconnectButton.isEnabled = enabled
        binding.sendButton.isEnabled = enabled
        binding.exportButton.isEnabled = enabled
        binding.deviceSpinner.isEnabled = enabled
        binding.sendInput.isEnabled = enabled
        binding.hexSendCheck.isEnabled = enabled
        binding.hexDisplayCheck.isEnabled = enabled
        binding.parseCheck.isEnabled = enabled
        binding.manageAccountsButton.isEnabled = enabled
        binding.autoSaveMinutesInput.isEnabled = enabled
        binding.autoSaveButton.isEnabled = enabled
        binding.cmdInput1.isEnabled = enabled
        binding.cmdInput2.isEnabled = enabled
        binding.cmdInput3.isEnabled = enabled
        binding.cmdInput4.isEnabled = enabled
        binding.cmdSend1.isEnabled = enabled
        binding.cmdSend2.isEnabled = enabled
        binding.cmdSend3.isEnabled = enabled
        binding.cmdSend4.isEnabled = enabled
        if (!enabled) {
            stopAutoSave()
        }
    }

    private fun isLoggedIn(): Boolean {
        val prefs = getSharedPreferences("auth_prefs", MODE_PRIVATE)
        return prefs.getBoolean("logged_in", false)
    }

    private fun hasBluetoothConnectPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    private fun requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN
                ),
                1001
            )
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                1002
            )
        }
    }

    override fun onDestroy() {
        disconnect(true)
        executor.shutdownNow()
        super.onDestroy()
    }
}
