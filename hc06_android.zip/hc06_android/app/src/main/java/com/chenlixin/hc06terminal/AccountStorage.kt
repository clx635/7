package com.chenlixin.hc06terminal

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Account(val username: String, val password: String)

object AccountStorage {
    private const val PREFS = "account_store"
    private const val KEY = "accounts"

    fun load(context: Context): MutableList<Account> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY, "[]") ?: "[]"
        val list = mutableListOf<Account>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i)
                val user = obj?.optString("u").orEmpty()
                val pass = obj?.optString("p").orEmpty()
                if (user.isNotBlank() && pass.isNotBlank()) {
                    list.add(Account(user, pass))
                }
            }
        } catch (_: Exception) {
        }
        return list
    }

    fun save(context: Context, accounts: List<Account>) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray()
        accounts.forEach {
            val obj = JSONObject()
            obj.put("u", it.username)
            obj.put("p", it.password)
            arr.put(obj)
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }
}
